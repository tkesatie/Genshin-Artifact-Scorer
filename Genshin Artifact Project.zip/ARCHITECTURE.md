# Genshin Artifact Scorer - Architecture Overview

## Data Flow
GOOD JSON + YAML Configs -> validate_config -> score.py (main) -> character_scoring / optimizer -> render_html & snapshot

## Key File Responsibilities
- **score.py**: Application entry point and pipeline orchestrator.
- **models.py**: Core `TypedDict` definitions (`Artifact`, `CharacterStats`, `BuildContext`).
- **artifact_utils.py**: GOOD format parser and substat roll resolution.
- **stats_calculator.py & damage_calculator.py**: Total stat aggregation and EM/Damage formulas.
- **character_scoring.py & bench.py**: Character evaluation loop and max-projected artifact ceilings.
- **optimizer.py**: Candidate build generation and optimal probability math.
- **recommendations.py & flex.py**: Upgrade pathing and off-piece slot evaluation.
- **snapshot.py & render_html.py**: Progress tracking and dashboard HTML rendering.